<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vjezba 7</title>
</head>
<body>
        <h1>Kalkulator ocjena</h1>
        <form method="POST" action="">
            <label for="kol1">Ocjena prvog kolokvija (1-5):</label>
            <input type="number" name="kol1" id="kol1" min="1" max="5" required>
            <br>
            <br>
            <label for="kol2">Ocjena drugog kolokvija (1-5):</label>
            <input type="number" name="kol2" id="kol2" min="1" max="5" required>
            <br>
            <br>
            <input type="submit" value="Izračunaj">
            <br>
            <br>
        </form>

        <?php
        if (isset($_POST['kol1'], $_POST['kol2'])) {
            $kol1 = $_POST['kol1'];
            $kol2 = $_POST['kol2'];
            $poruka = "";

            if ($kol1 < 1 || $kol1 > 5 || $kol2 < 1 || $kol2 > 5) {
                $poruka = "Ocjene moraju biti između 1 i 5.";
            } elseif ($kol1 < 2 || $kol2 < 2) {
                $poruka = "Jedan od kolokvija je negativan. Konačna ocjena: nedovoljan (1).";
            } else {
                $prosjek = ($kol1 + $kol2) / 2;
                $konacna = round($prosjek);
                $poruka = "Prosjek: " . $prosjek . "<br>Konačna ocjena: " . $konacna;
            }

            echo '<div class="rezultat">' . $poruka . '</div>';
        }
        ?>
</body>
</html>
