<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marke vozila</title>
  </head>
  <body>
    <form action="" method="post">
    <label for="audi">Označi vozilo od ponuđenih:</label>
    <br><br>

    <input type="radio" name="vozila" value="Audi" id="audi">
    <label for="audi">Audi</label>
    <br><br>

    <input type="radio" name="vozila" value="BMW" id="bmw">
    <label for="bmw">BMW</label>
    <br><br>

    <input type="radio" name="vozila" value="Renault" id="renault">
    <label for="renault">Renault</label>
    <br><br>

    <input type="radio" name="vozila" value="Citroen" id="citroen">
    <label for="citroen">Citroen</label>
    <br><br>

    <input type="submit" value="Pošalji">
    <br><br>
    </form>
    <?php 
      if (isset($_POST['vozila'])) {
        $odabranoVozilo = $_POST['vozila'];
        print '
        <p>Odabrali ste vozilo marke: <strong>'.$odabranoVozilo.'</strong></p>';
      }
      ?>
  </body>
</html>