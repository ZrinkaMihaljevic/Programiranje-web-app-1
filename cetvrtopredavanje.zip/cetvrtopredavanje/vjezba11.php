<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Provjera prostih brojeva</title>
</head>
<body>
    <h2>Provjera prostih brojeva</h2>

    <form method="post" action="">
        <label for="broj">Unesi broj:</label>
        <input type="number" name="broj" id="broj" min="2" required>
        <input type="submit" value="Provjeri">
    </form>

    <?php
    function jeProst($broj) {
        if ($broj <= 1) return false;
        for ($i = 2; $i <= sqrt($broj); $i++) {
            if ($broj % $i == 0) {
                return false;
            }
        }
        return true;
    }

    if (isset($_POST['broj'])) {
        $uneseniBroj = (int)$_POST['broj'];

        if (jeProst($uneseniBroj)) {
            echo "<p>$uneseniBroj je prost broj.</p>";
        } else {
            echo "<p>$uneseniBroj nije prost broj.</p>";
        }

        echo "<p>Prosti brojevi manji od $uneseniBroj su:</p><p>";
        for ($i = 2; $i < $uneseniBroj; $i++) {
            if (jeProst($i)) {
                echo $i . " ";
            }
        }
        echo "</p>";
    }
    ?>
</body>
</html>
