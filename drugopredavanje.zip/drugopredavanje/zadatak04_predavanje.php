<!DOCTYPE html>
<html lang="hr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Operatori</title>
</head>
<body>
	<?php
		$a = $_POST['vrijednost-a'];
		$b = $_POST['vrijednost-b'];
		$c = (3 * $a - $b) / 2;

		echo '
			<div class="odlomak">
				<p>a = '.$a.'</p>
				<p>b = '.$b.'</p>
				<p>c = (3 * '.$a.' - '.$b.') / 2 = '.$c.'</p>
			</div>
		';
	?>
</body>
</html>