<?php
function jeDucanOtvoren() {
    $trenutnoVrijeme = new DateTime();
    $dan = $trenutnoVrijeme->format('w');
    $sat = (int)$trenutnoVrijeme->format('G'); 

    $praznici = [
        '01-01', // Nova godina
        '05-01', // Praznik rada
        '06-22', // Dan antifašističke borbe
        '06-25', // Dan državnosti
        '08-05', // Dan pobjede
        '08-15', // Velika Gospa
        '10-08', // Dan neovisnosti
        '11-01', // Svi sveti
        '12-25', // Božić
        '12-26'  // Sveti Stjepan
    ];

    $danasnjiDatum = $trenutnoVrijeme->format('m-d');

    if (in_array($danasnjiDatum, $praznici)) {
        return "Danas je praznik - dućan je zatvoren.";
    }

    if ($dan == 0) {
        return "Danas je nedjelja - dućan je zatvoren.";
    } elseif ($dan == 6) {
        if ($sat >= 9 && $sat < 14) {
            return "Dućan je trenutno otvoren.";
        } else {
            return "Dućan je trenutno zatvoren.";
        }
    } else {
        if ($sat >= 8 && $sat < 20) {
            return "Dućan je trenutno otvoren.";
        } else {
            return "Dućan je trenutno zatvoren.";
        }
    }
}

echo jeDucanOtvoren();
?>
