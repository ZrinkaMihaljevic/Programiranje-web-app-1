<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $host = "localhost";
    $db = "korisnici_registracija";
    $user = "root";
    $pass = "";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_error) {
        die("Greška pri spajanju: " . $conn->connect_error);
    }

    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $email = $_POST['email'];
    $korisnicko_ime = $_POST['korisnicko_ime'];
    $lozinka = password_hash($_POST['lozinka'], PASSWORD_DEFAULT);
    $drzava = $_POST['drzava'];

    $sql = "INSERT INTO korisnici (ime, prezime, email, korisnicko_ime, lozinka, drzava) 
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $ime, $prezime, $email, $korisnicko_ime, $lozinka, $drzava);

    if ($stmt->execute()) {
        $poruka = "Registracija uspješna!";
    } else {
        $poruka = "Greška: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registracija korisnika</title>
</head>
<body>
    <h2>Registration Form</h2>

    <?php if (!empty($poruka)): ?>
        <p><strong><?php echo $poruka; ?></strong></p>
    <?php endif; ?>

    <form method="post" action="">
        <label>First Name *</label><br>
        <input type="text" name="ime" required><br><br>

        <label>Last Name *</label><br>
        <input type="text" name="prezime" required><br><br>

        <label>Your E-mail *</label><br>
        <input type="email" name="email" required><br><br>

        <label>Username * (min 5, max 10 znakova)</label><br>
        <input type="text" name="korisnicko_ime" minlength="5" maxlength="10" required><br><br>

        <label>Password * (min 4 znaka)</label><br>
        <input type="password" name="lozinka" minlength="4" required><br><br>

        <label>Country</label><br>
        <select name="drzava" required>
            <option value="">molimo odaberite</option>
            <option value="Hrvatska">Hrvatska</option>
            <option value="Srbija">Srbija</option>
            <option value="BiH">Bosna i Hercegovina</option>
            <option value="Slovenija">Slovenija</option>
        </select><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
