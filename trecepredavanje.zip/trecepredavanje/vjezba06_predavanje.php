<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vjezba 6</title>
</head>
<body>
    <h1>Kalkulator (switch naredba)</h1>
    <form action="" method="POST" id="kalkulator">
        <label for="broj1">Unesite prvi broj</label>
        <input type="number" name="broj1" id="broj1" required autofocus>
        <br><br>
        <label for="broj2">Unesite drugi broj</label>
        <input type="number" name="broj2" id="broj2" required>
        <br><br>
        <input type="submit" value="+" name="operator">
        <input type="submit" value="-" name="operator">
        <input type="submit" value="*" name="operator">
        <input type="submit" value="/" name="operator">
    </form>

    <?php
    if (isset($_POST["broj1"], $_POST["broj2"], $_POST["operator"])) {
        $prviBroj = $_POST["broj1"];
        $drugiBroj = $_POST["broj2"];
        $operator = $_POST["operator"];
        $rezultat = '';

        switch ($operator) {
            case "+":
                $rezultat = $prviBroj + $drugiBroj;
                break;
            case "-":
                $rezultat = $prviBroj - $drugiBroj;
                break;
            case "*":
                $rezultat = $prviBroj * $drugiBroj;
                break;
            case "/":
                if ($drugiBroj != 0) {
                    $rezultat = $prviBroj / $drugiBroj;
                } else {
                    $rezultat = "Dijeljenje s nulom nije dozvoljeno!";
                }
                break;
            default:
                $rezultat = "Nepoznata operacija.";
                break;
        }

        echo '<h2>Rezultat: ' . $rezultat . '</h2>';
    }
    ?>
</body>
</html>
