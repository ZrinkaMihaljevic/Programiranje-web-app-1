<?php
    $title = "Da Vincijev kod";
    $link = "https://hr.wikipedia.org/wiki/Da_Vincijev_kod"; 

    echo "<h1>$title</h1>";
    echo "<p>$title je kriminalistički triler američkog pisca Dana Browna.</p>";
    echo "<a href=\"$link\" target=\"_blank\">Više o knjizi</a>";
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Stranica o Da Vincijevom kodu">
    <meta name="keywords" content="Da Vinci, Da Vincijev kod, Dan Brown, knjiga">
    <title>Da Vincijev kod</title>
</head>
<body>
    <!-- Naziv datoteke: locahost/drugopredavanje/index.php -->
</body>
</html>