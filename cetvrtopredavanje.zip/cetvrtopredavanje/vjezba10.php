<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Zadatak str_word_count</title>
</head>
<body>
    <h2>Zadatak str_word_count</h2>

    <form action="" method="post">
        <label for="tekst">Ulazni niz:</label><br>
        <input type="text" name="tekst" id="tekst" size="80"><br><br>
        <input type="submit" value="Ispiši broj riječi">
    </form>

    <?php
    if (isset($_POST['tekst'])) {
        $ulaz = $_POST['tekst'];
        $brojRijeci = str_word_count($ulaz);
        echo "<p>Ulazni niz: $ulaz</p>";
        echo "<p>Rečenica sadrži $brojRijeci riječi.</p>";
    }
    ?>
</body>
</html>
